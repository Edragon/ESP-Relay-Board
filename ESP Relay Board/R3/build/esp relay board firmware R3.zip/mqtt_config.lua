local M = {}

M.HOST = "m13.cloudmqtt.com"
M.PORT = 14967
M.MQTTUSER = "jtpfneeq"
M.MQTTPASS = "4Og5kJ5WYQYT"

M.ENDPOINT = "nodemcu/"

return M  
